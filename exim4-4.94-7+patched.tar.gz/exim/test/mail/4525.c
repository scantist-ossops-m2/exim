From CALLER@myhost.test.ex Tue Mar 02 09:44:33 1999
Received: from the.local.host.name ([ip4.ip4.ip4.ip4] helo=myhost.test.ex)
	by myhost.test.ex with esmtp (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmbC-0005vi-00
	for c@test.ex; Tue, 2 Mar 1999 09:44:33 +0000
DKIM-Signature: v=1; a=rsa-sha256; q=dns/txt; c=relaxed/relaxed; d=test.ex;
	s=sel; h=From; bh=bzHKix52TV0ojCi2kd18gmIw/tcd5TnhO3QM+89xwyk=; b=LcQAFwKN9DL
	wCbK0mcUtjmEoLaNUjwHmVrilQI1nBWJDoDUzpUl96U8YzdS/+Xut+pdS/YZf3m/Qbcw6ohO9pEmM
	ncfURg55wr8fftAyRFA/L/svtP8h3Qv/+jv8gJ9nHyjk3z7Zmzzo8S54h9Ct9pJwkv0cpmdeLiDrL
	ygZGjs=;
Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmbB-0005vi-00
	for c@test.ex; Tue, 2 Mar 1999 09:44:33 +0000
From: nobody@example.com
Message-Id: <E10HmbB-0005vi-00@myhost.test.ex>
Sender: CALLER_NAME <CALLER@myhost.test.ex>
Date: Tue, 2 Mar 1999 09:44:33 +0000

content

-- 
This is a generic mailinglist footer, using a traditional .sig-separator line
----

From CALLER@myhost.test.ex Tue Mar 02 09:44:33 1999
Received: from the.local.host.name ([ip4.ip4.ip4.ip4] helo=myhost.test.ex)
	by myhost.test.ex with esmtp (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmbG-0005vi-00
	for c@test.ex; Tue, 2 Mar 1999 09:44:33 +0000
DKIM-Signature: v=1; a=rsa-sha256; q=dns/txt; c=relaxed/relaxed; d=test.ex;
	s=sel; h=From; bh=bzHKix52TV0ojCi2kd18gmIw/tcd5TnhO3QM+89xwyk=; b=LcQAFwKN9DL
	wCbK0mcUtjmEoLaNUjwHmVrilQI1nBWJDoDUzpUl96U8YzdS/+Xut+pdS/YZf3m/Qbcw6ohO9pEmM
	ncfURg55wr8fftAyRFA/L/svtP8h3Qv/+jv8gJ9nHyjk3z7Zmzzo8S54h9Ct9pJwkv0cpmdeLiDrL
	ygZGjs=;
Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmbF-0005vi-00
	for c@test.ex; Tue, 2 Mar 1999 09:44:33 +0000
From: nobody@example.com
Message-Id: <E10HmbF-0005vi-00@myhost.test.ex>
Sender: CALLER_NAME <CALLER@myhost.test.ex>
Date: Tue, 2 Mar 1999 09:44:33 +0000

content

-- 
This is a generic mailinglist footer, using a traditional .sig-separator line
----


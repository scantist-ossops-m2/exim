$Cambridge: exim/release-process/README.txt,v 1.1 2010/06/03 12:00:38 nm4 Exp $

This directory contains stuff for the exim release process.

Initially the scripts directory contains some scripting to build
the release packages and to sign the packages.

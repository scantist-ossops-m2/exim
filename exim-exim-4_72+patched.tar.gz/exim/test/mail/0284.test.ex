From CALLER@test.ex Tue Mar 02 09:44:33 1999
Envelope-to: x-t3@test.ex,
 y-t3@test.ex
Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@test.ex>)
	id 10HmaZ-0005vi-00; Tue, 2 Mar 1999 09:44:33 +0000
Date: Tue, 2 Mar 1999 09:44:33 +0000
Message-Id: <E10HmaZ-0005vi-00@myhost.test.ex>
From: CALLER_NAME <CALLER@test.ex>



Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmaY-0005vi-00
	for userx@myhost.test.ex; Tue, 2 Mar 1999 09:44:33 +0000
Date: Tue, 2 Mar 1999 09:44:33 +0000
Message-Id: <E10HmaY-0005vi-00@myhost.test.ex>
maildir:maildir_
From: CALLER_NAME <CALLER@myhost.test.ex>

This is a test message

/*************************************************
*     Exim - an Internet mail transport agent    *
*************************************************/

/* Copyright (c) Google, Inc. 2010 */
/* See the file NOTICE for conditions of use and distribution. */

/* This is bumped by the Exim Maintainers, the release engineer: */
#define EXIM_RELEASE_VERSION_STR        "4.74"
/* If you apply extensive local patches, consider putting -foo into here */
#define EXIM_VARIANT_VERSION            ""

#define EXIM_VERSION_STR        EXIM_RELEASE_VERSION_STR EXIM_VARIANT_VERSION

/* End of version.h */

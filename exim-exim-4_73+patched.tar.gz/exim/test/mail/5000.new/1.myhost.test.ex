Received: from CALLER by myhost.test.ex with local (Exim x.yz)
	(envelope-from <CALLER@myhost.test.ex>)
	id 10HmaY-0005vi-00
	for userx@myhost.test.ex; Tue, 2 Mar 1999 09:44:33 +0000
maildir:maildir_
Message-Id: <E10HmaY-0005vi-00@myhost.test.ex>
From: CALLER_NAME <CALLER@myhost.test.ex>
Date: Tue, 2 Mar 1999 09:44:33 +0000

This is a test message

The contents of this file are not used. Its name is used as a way of specifying
the domain that is to be used to qualify unqualified domain names when given to
the fake DNS resolver.
